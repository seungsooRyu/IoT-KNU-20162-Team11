#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Sort.h"

int compare(const void*, const void*);

void Quick(int number, ListNodePtr *currentPtr)
{
	char word[WORDLEN];
	char strList[STRMAX][WORDLEN];
	int i;

	if (currentPtr == NULL) {
		printf("List is empty\n");
	}
	else {
		for (i = 0; i < number; i++)
		{
			strcpy_s(strList[i], sizeof(strList[i]), (*currentPtr)->data);
			(*currentPtr) = (*currentPtr)->nextPtr;
		}
	}
	
	qsort(strList, number, sizeof(strList[0]), compare);

	for (i = 0; i < number; i++) {
		printf("%d\t\t%s\n", i + 1, strList[i]);
	}
}

int compare(const void *a, const void *b) {
	return strcmp((char*)a, (char*)b);
}