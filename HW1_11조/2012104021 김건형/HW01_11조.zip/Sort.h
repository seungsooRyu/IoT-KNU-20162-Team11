#ifndef __SORT__
#define __SORT__
#include "LinkedList.h"

#define WORDLEN 20
#define STRMAX 100

void Bubble(int, ListNodePtr);
void Quick(int, ListNodePtr);
void Heap(int, ListNodePtr);
void Merge(int, ListNodePtr);

#endif