#include <stdio.h>
#include "LinkedList.h"
#include "Sort.h"

void heapsort(char[][20], int);
void heapify(char[][20], int);
void adjust(char[][20], int);

void Heap(int number, ListNodePtr *currentPtr)
{
	char word[WORDLEN];
	char strList[STRMAX][WORDLEN];
	int i;

	if (currentPtr == NULL) {
		printf("List is empty\n");
	}
	else {
		for (i = 0; i < number; i++)
		{
			strcpy_s(strList[i], sizeof(strList[i]), (*currentPtr)->data);
			(*currentPtr) = (*currentPtr)->nextPtr;
		}
	}

	heapsort(strList, number);

	for (i = 0; i < number; i++) {
		printf("%d\t\t%s\n", i + 1, strList[i]);
	}
}

void adjust(char a[][20], int n)
{
	int i, j;
	char item[20];

	j = 0;
	strcpy_s(item, sizeof(item), a[j]);
	i = 2 * j + 1;

	while (i <= n - 1) {
		if (i + 1 <= n - 1)
			if (strcmp(a[i], a[i + 1]) < 0)
				i++;
		if (strcmp(item, a[i]) < 0) {
			strcpy_s(a[j], sizeof(a[j]), a[i]);
			j = i;
			i = 2 * j + 1;
		}
		else
			break;
	}
	strcpy_s(a[j], sizeof(a[j]), item);
}

void heapsort(char a[][20], int n)
{
	int i;
	char temp[20];

	heapify(a, n);

	for (i = n - 1; i > 0; i--) {
		strcpy_s(temp, sizeof(temp), a[0]);
		strcpy_s(a[0], sizeof(a[0]), a[i]);
		strcpy_s(a[i], sizeof(a[i]), temp);
		adjust(a, i);
	}
}

void heapify(char a[][20], int n)
{
	int k, i, j;
	char item[20];

	for (k = 1; k<n; k++)	{
		strcpy_s(item, sizeof(item), a[k]);
		i = k;
		j = (i - 1) / 2;

		while ((i>0) && (strcmp(item,a[j])>0))		{
			strcpy_s(a[i], sizeof(a[i]), a[j]);
			i = j;
			j = (i - 1) / 2;
		}
		strcpy_s(a[i], sizeof(a[i]), item);
	}
}