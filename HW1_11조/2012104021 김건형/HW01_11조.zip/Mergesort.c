#include <stdio.h>
#include "LinkedList.h"
#include "Sort.h"

void merge_sort(char a[][20], int left, int right);
void merge_merge(char a[][20], int left, int mid, int right);

void Merge(int number, ListNodePtr *currentPtr)
{
	char word[WORDLEN];
	char strList[STRMAX][WORDLEN];
	int i;

	if (currentPtr == NULL) {
		printf("List is empty\n");
	}
	else {
		for (i = 0; i < number; i++)
		{
			strcpy_s(strList[i], sizeof(strList[i]), (*currentPtr)->data);
			(*currentPtr) = (*currentPtr)->nextPtr;
		}
	}

	merge_sort(strList, 0, number - 1);


	for (i = 0; i < number; i++) {
		printf("%d\t\t%s\n", i + 1, strList[i]);
	}
}

void merge_sort(char a[][20], int left, int right)
{
	int mid;

	if (left < right) {
		mid = (left + right) / 2;

		merge_sort(a, left, mid);
		merge_sort(a, mid + 1, right);
		merge_merge(a, left, mid, right);
	}
}

void merge_merge(char a[][20], int left, int mid, int right)
{
	int i, j, k, m;
	char tempArray[STRMAX][WORDLEN];

	i = left;
	j = mid + 1;
	k = left;

	while (i <= mid && j <= right) {
		if (strcmp(a[i], a[j]) < 0) {
			strcpy_s(tempArray[k], sizeof(tempArray[k]), a[i]);
			i++;
		}
		else {
			strcpy_s(tempArray[k], sizeof(tempArray[k]), a[j]);
			j++;
		}
		k++;
	}

	// all clear left but not yet right index
	if (i > mid) {
		for (m = j; m <= right; m++) {
			strcpy_s(tempArray[k], sizeof(tempArray[k]), a[m]);
			k++;
		}
	}
	// net yet left index
	else {
		for (m = i; m <= mid; m++) {
			strcpy_s(tempArray[k], sizeof(tempArray[k]), a[m]);
			k++;
		}
	}

	for (m = left; m <= right; m++) {
		strcpy_s(a[m], sizeof(a[m]), tempArray[m]);
	}
}