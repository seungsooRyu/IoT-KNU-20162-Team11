#include <stdio.h>
#include "LinkedList.h"
#include "Sort.h"

void Bubble(int number, ListNodePtr *currentPtr)
{
	char word[WORDLEN];
	char strList[STRMAX][WORDLEN];
	int loop, i;

	if (currentPtr == NULL) {
		printf("List is empty\n");
	}
	else {
		for (i = 0; i < number; i++)
		{
			strcpy_s(strList[i], sizeof(strList[i]), (*currentPtr)->data);
			(*currentPtr) = (*currentPtr)->nextPtr;
		}
	}

	for (loop = 0; loop < number - 1; loop++) {
		for (i = 0; i < number - 1 - loop; i++) {
			if (strcmp(strList[i], strList[i + 1])>0) {
				strcpy_s(word, sizeof(word), strList[i]);
				strcpy_s(strList[i], sizeof(strList[i]), strList[i + 1]);
				strcpy_s(strList[i + 1], sizeof(strList[i + 1]), word);
			}
		}
	}

	for (i = 0; i < number; i++) {
		printf("%d\t\t%s\n", i+1, strList[i]);
	}
}