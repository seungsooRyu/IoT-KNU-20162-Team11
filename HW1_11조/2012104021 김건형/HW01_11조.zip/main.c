#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "LinkedList.h"

int main() 
{
	int i;
	float gap;
	time_t startTime = 0, endTime = 0;
	ListNodePtr startPtr = NULL;
	char item[20];
	int overlap;
	FILE *f;
	char strlist[100][20];

	fopen_s(&f, "Input.txt", "r");

	printf("Input data by Text File\n\n");
	for (int i=0; i<1024; i++) {
		fscanf_s(f, "%s", item, sizeof(item));
		if (item[0] == '\0') break;
		insert(&startPtr, item);
		item[0] = '\0';
	}
	
	//original homework
	while (1) {
		instructions();
		scanf_s("%s", item, sizeof(item));
		if (strcmp(item, "Q") == 0) break;
		else {
			overlap = search(&startPtr, item);
			if (overlap) {
				if (overlap == 1) {
					printf("%s is founded. this word shown once.\n", item);
					printf("This word's index is %d.\n\n", indexnumber[0]);
				}
				else if (overlap > 1) {
					printf("%s is founded. this word shown %d times.\n", item, overlap);
					for (int i = 0; i < overlap; i++) {
						printf("This word's index is %d.\n", indexnumber[i]);
					}
				}
				printf("\n");
			}
			else
			{
				printf("%s is not found.\n\n", item);
			}
		}

		//additional homework
		//bubble sort
		if (strcmp(item, "BS") == 0) {
			printf("Bubble Sort Start\n\n");
			startTime = clock();
			Bubble(count, &startPtr);
			endTime = clock();
			gap = (float)(endTime - startTime) / (CLOCKS_PER_SEC);
			printf("Gap : %f sec\n", gap);
			break;
		}
		//quick sort
		if (strcmp(item, "QS") == 0) {
			printf("Quick Sort Start\n\n");
			startTime = clock();
			Quick(count, &startPtr);
			endTime = clock();
			gap = (float)(endTime - startTime) / (CLOCKS_PER_SEC);
			printf("Gap : %f sec\n", gap);
			break;
		}
		//Heap sort
		if (strcmp(item, "HS") == 0) {
			printf("Heap Sort Start\n\n");
			startTime = clock();
			Heap(count, &startPtr);
			endTime = clock();
			gap = (float)(endTime - startTime) / (CLOCKS_PER_SEC);
			printf("Gap : %f sec\n", gap);
			break;
		}
		//Merge sort
		if (strcmp(item, "MS") == 0) {
			printf("Merge Sort Start\n\n");
			startTime = clock();
			Merge(count, &startPtr);
			endTime = clock();
			gap = (float)(endTime - startTime) / (CLOCKS_PER_SEC);
			printf("Gap : %f\n", gap);
			break;
		}
	}

	printf("\nEnd of run.\n");
	return 0;
}


void instructions(void)
{
	printf("Word what you want find or BS, QS, HS, MS or Q : ");
}